﻿namespace hotel_management_API.Models.DTO
{
    public class LoginResponseDto
    {
        public string? token { get; set; }
        public string? Name {  get; set; }
        public string? Role { get; set; }

    }
}
