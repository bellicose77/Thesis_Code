﻿namespace hotel_management_API.Models.DTO
{
    public class LogInDto
    {
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
